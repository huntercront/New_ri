var btn = document.getElementById("m_menu");
var btnm = document.getElementById("m_memu_text");
	btn.onclick= function() {
		btnm.classList.toggle("manu-active");
					btn.classList.toggle("buttion-active");
			}
